if [ -f "example.txt" ]; then
    echo "File exists: example.txt"
else
    echo "File does not exist: example.txt"
fi
